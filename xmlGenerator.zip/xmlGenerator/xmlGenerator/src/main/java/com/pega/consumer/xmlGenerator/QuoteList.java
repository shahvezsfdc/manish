package com.pega.consumer.xmlGenerator;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "quotes")
public class QuoteList {
	
	@XmlElement(name = "employee")
    private List<Quote> quote = null;
 
    public List<Quote> getEmployees() {
        return quote;
    }
 
    public void setEmployees(List<Quote> quote) {
        this.quote = quote;
    }

}

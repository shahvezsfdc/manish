package com.pega.consumer.xmlGenerator;

import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.opencsv.CSVReader;

@SpringBootApplication
public class XmlGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlGeneratorApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
		return args -> {
			//Quote quote = restTemplate.getForObject("https://gturnquist-quoters.cfapps.io/api/random", Quote.class);
			//System.out.println(quote.toString());
			QuoteList quotes = parseCSVFileLineByLine();

			try {
				// Create JAXB Context
				JAXBContext jaxbContext = JAXBContext.newInstance(QuoteList.class);

				// Create Marshaller
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

				// Required formatting??
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

				// Print XML String to Console
				StringWriter sw = new StringWriter();

				String xmlContent="";
				// Write XML to StringWriter
				jaxbMarshaller.marshal(quotes, sw);

				// Verify XML Content
				xmlContent = sw.toString();
				
				System.out.println(xmlContent);

			} catch (JAXBException e) {
				e.printStackTrace();
			}
		};
	}
	
	private static QuoteList parseCSVFileLineByLine() throws IOException {
		//create CSVReader object
		CSVReader reader = new CSVReader(new FileReader("excel.csv"), ',');
		
		List<Quote> emps = new ArrayList<Quote>();
		//read line by line
		String[] record = null;
		//skip header row
		reader.readNext();
		
		while((record = reader.readNext()) != null){
			Quote emp = new Quote();
			emp.setType(record[0]);
			emp.setValue(record[1]);
			emps.add(emp);
		}
		
		reader.close();
		
		System.out.println(emps);
		QuoteList list = new QuoteList();
		list.setEmployees(emps);
		return list;
	}

}

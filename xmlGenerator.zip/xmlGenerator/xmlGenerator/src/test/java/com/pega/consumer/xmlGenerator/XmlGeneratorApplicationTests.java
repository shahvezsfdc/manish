package com.pega.consumer.xmlGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
